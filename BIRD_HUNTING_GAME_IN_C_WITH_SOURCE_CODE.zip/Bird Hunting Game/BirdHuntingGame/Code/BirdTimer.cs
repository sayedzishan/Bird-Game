﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BirdHuntingGame.Code
{
	public class BirdTimer : Timer
	{
		public BirdBox BirdBox { get; set; }
	}
}
